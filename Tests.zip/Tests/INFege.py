from sqlalchemy import create_engine, text, Connection, MetaData, Table, Integer, String, BigInteger, ForeignKey, select, Column, insert
import sqlite3
from sqlalchemy.orm import Session, registry, declarative_base, as_declarative, declared_attr, mapped_column, Mapped


engine = create_engine('sqlite+pysqlite:///db/Video_test.db', echo=True)
metadata = MetaData()

user_table = Table(
    "users",
    metadata,
    Column('id', Integer, primary_key=True, unique=True, autoincrement=True),
    Column('name', String(30)),
    Column('fullname', String),
)

address_table = Table(
    "addresses",
    metadata,
    Column('id', Integer, primary_key=True, unique=True, autoincrement=True),
    Column('email_address', String(30)),
    Column('user_id', ForeignKey('users.id')),
)

metadata.create_all(engine)

stmt = insert(user_table).values(name="test", fullname="Test")
stmt_wo_values = insert(user_table)
sqlite3_stmt = stmt_wo_values.compile(engine, engine.dialect)

with engine.begin() as conn: # type: Connectoin
    result = conn.execute(
        stmt_wo_values,
        [
            {'name': "test1", "fullname": "Test1 full"},
            {'name': "test2", "fullname": "Test2 full"},
            {'name': "test3", "fullname": "Test3 full"},
        ]

    )

































#
# user_table = Table('users',
#                    metadata,
#                    mapped_column('id', Integer, primary_key=True),
#                    mapped_column('user_id', BigInteger, unique=False),
#                    mapped_column('fullname', String),
#                    )
# address = Table('addresses',
#                    metadata,
#                    mapped_column('id', Integer, primary_key=True),
#                    mapped_column('user_id', ForeignKey('users.user_id')),
#                    mapped_column('email', String, nullable=False),
#                    )
#
# metadata.create_all(engine)
# metadata.drop_all(engine)

# mapper_regesry = registry()

#Понты
# @as_declarative()
# class AbstractModel:
#     id: Mapped[int] = mapped_column(Integer, autoincrement=True, primary_key=True)
#
#
#     @classmethod
#     @declared_attr
#     def __tablename__(cls) -> str:
#         return cls.__name__.lower()
#
#
# class UserModel(AbstractModel):
#     __tablename__ = 'users'
#     user_id: Mapped[int] = mapped_column(BigInteger)
#     name: Mapped[str] = mapped_column()
#     fullname: Mapped[str] = mapped_column()
#
#
# class AddressModel(AbstractModel):
#     __tablename__ = 'addresses'
#     email = mapped_column(String, nullable=False)
#     user_id = mapped_column(ForeignKey('users.id'))
#
#
# with Session(engine) as session:
#     with session.begin():
#         AbstractModel.metadata.create_all(engine)
#         user = UserModel(user_id=1, name='Rassel', fullname='Rassel Crow')
#         session.add(user)
#     with session.begin():
#         res = session.execute(select(UserModel).where(UserModel.user_id == 1))
#         user = res.scalar()
#